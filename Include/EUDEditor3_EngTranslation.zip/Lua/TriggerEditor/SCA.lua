function SCALoad(Slot, CompleteFunc) --SCA/Number,Function/Load the data of [Slot]. When loading is complete, [CompleteFunc] is called.
	preDefine("import TriggerEditor.SCAWrapper as scaWrapper;")
	beforeText("scaWrapper.Exec();")


	local funcname = string.match(CompleteFunc, "%a+")
		
	echo("scaWrapper.scaLoad(".. Slot .. ", EUDFuncPtr(0, 0)(f_" .. funcname .. "))");
end
function SCASave(Slot, CompleteFunc) --SCA/Number,Function/Save the data of [Slot]. When saving is complete, [CompleteFunc] is called.
	preDefine("import TriggerEditor.SCAWrapper as scaWrapper;")
	beforeText("scaWrapper.Exec();")


	local funcname = string.match(CompleteFunc, "%a+")
		
	echo("scaWrapper.scaSave(".. Slot .. ", EUDFuncPtr(0, 0)(f_" .. funcname .. "))");
end
function SCATime(CompleteFunc) --SCA/Function/Load time information. When loading is complete, [CompleteFunc] is called.
	preDefine("import TriggerEditor.SCAWrapper as scaWrapper;")
	beforeText("scaWrapper.Exec();")


	local funcname = string.match(CompleteFunc, "%a+")
		
	echo("scaWrapper.scaLoadTime(EUDFuncPtr(0, 0)(f_" .. funcname .. "))");
end
function SCAGlobalData(CompleteFunc) --SCA/Function/Load the global variables. When loading is complete, [CompleteFunc] is called.
	preDefine("import TriggerEditor.SCAWrapper as scaWrapper;")
	beforeText("scaWrapper.Exec();")


	local funcname = string.match(CompleteFunc, "%a+")
		
	echo("scaWrapper.scaLoadGlobal(EUDFuncPtr(0, 0)(f_" .. funcname .. "))");
end