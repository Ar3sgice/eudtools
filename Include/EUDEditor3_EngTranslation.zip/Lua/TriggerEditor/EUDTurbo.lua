function EUDTurbo() --Basic//Activate EUDTurbo.
	echo("SetMemoryEPD(EPD(0x6509A0), SetTo, 0)")
end
