function SetCompletedUnitCount(Unit, Player, Modifier, Amount) --Basic/TrgUnit,TrgPlayer,TrgModifier,Number/Modify completed unit counts for [Player]: [Modifier] [Amount] for [Unit].
	Player = ParsePlayer(Player)
    Modifier = ParseModifier(Modifier)
    Unit = ParseUnit(Unit)
    OffsetEPD = CompletedUnitCountEPD(Unit, Player)


	echo(string.format("SetMemoryEPD(%s, %s, %s)", OffsetEPD, Modifier, Amount))
end
function GetCompletedUnitCount(Unit, Player) --Basic/TrgUnit,TrgPlayer/Get completed [Unit] count for [Player].
	Player = ParsePlayer(Player)
    Unit = ParseUnit(Unit)
    OffsetEPD = CompletedUnitCountEPD(Unit, Player)

	echo(string.format("dwread_epd(%s)", OffsetEPD))
end
function CompletedUnitCountEPD(Unit, Player) --Basic/TrgUnit,TrgPlayer/Get the memory address of completed [Unit] count for [Player].
	Player = ParsePlayer(Player)
    Unit = ParseUnit(Unit)
    Offset = 0x584DE4
	if IsNumber(Player) and IsNumber(Unit) then
		Offset = Offset + (Unit * 12 + Player) * 4
		return string.format("EPD(0x%X)", Offset)
	else
		return string.format("EPD(0x%X) + %s * 12 + %s", Offset, Unit, Player)
	end
end