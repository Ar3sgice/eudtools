function ChatEvent(Chat) --ChatEvent/TrgString/Recognize chat [Chat].
	chatindex = AddChatEventPlugin(Chat)
	--chatarray = "VChat_" .. chatindex
	chatarray = "VChatIndex"

	
	echo("MemoryEPD(EPD(msqcvar." .. chatarray .. ") + getcurpl(), Exactly, " .. chatindex + 1 ..")")
end

function ChatEventPattern(Start,Mid,End) --ChatEvent/TrgString,TrgString,TrgString/Recognize chat pattern [Start],[Mid],[End].
	Chat = "^" .. Start .. ".*" .. Mid .. ".*" .. End .. "$"
	chatindex = AddChatEventPlugin(Chat)
	--chatarray = "VChat_" .. chatindex
	chatarray = "VChatIndex"

	
	echo("MemoryEPD(EPD(msqcvar." .. chatarray .. ") + getcurpl(), Exactly, " .. chatindex + 1 ..")")
end

