function GetCounterTime() --Basic//Get the countdown timer seconds value.
	echo("dwread_epd(EPD(0x58D6F4))")
end
function CounterTimeOffset() --Basic//Get the countdown timer offset.
	echo("0x58D6F4")
end
