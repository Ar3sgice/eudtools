function SetVariable(Variable, Modifier, Value) --Variable/Variable,TrgModifier,Number/Set variable [Variable]: [Modifier] [Value].
	Modifier = ParseModifier(Modifier)

	if Modifier == 7 then
		strStart, strEnd = string.find(Variable, "%.")
		str = ""
		if strStart == nil then
			str = Variable .. " = " .. Value
		else
			str = string.format("SetVariables(%s, %s)", Variable, Value);
		end
		echo(str)
	elseif Modifier == 8 then
		str = Variable .. " += " .. Value

	
		echo(str)
	elseif Modifier == 9 then
		str = Variable .. " -= " .. Value

	
		echo(str)
	end
end

function Variable(Variable, Comparison, Value) --Variable/Variable,TrgComparison,Number/Variable [Variable] is [Comparison] [Value].
	Comparison = ParseComparison(Comparison)

	if Comparison == 0 then
		str = Variable .. " >= " .. Value

		echo(str)
	elseif Comparison == 1 then
		str = Variable .. " <= " .. Value

		echo(str)
	elseif Comparison == 10 then
		str = Variable .. " == " .. Value

		echo(str)
	end
end