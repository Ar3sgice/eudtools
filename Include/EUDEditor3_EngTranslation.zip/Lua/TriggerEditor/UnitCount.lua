function SetUnitCount(Unit, Player, Modifier, Amount) --Basic/TrgUnit,TrgPlayer,TrgModifier,Number/Set unit count for [Player]: [Modifier] [Amount] for [Unit].
	Player = ParsePlayer(Player)
    Modifier = ParseModifier(Modifier)
    Unit = ParseUnit(Unit)
    OffsetEPD = UnitCountEPD(Unit, Player)


	echo(string.format("SetMemoryEPD(%s, %s, %s)", OffsetEPD, Modifier, Amount))
end
function GetUnitCount(Unit, Player) --Basic/TrgUnit,TrgPlayer/Get unit count of [Unit] for [Player].
	Player = ParsePlayer(Player)
    Unit = ParseUnit(Unit)
    OffsetEPD = UnitCountEPD(Unit, Player)

	echo(string.format("dwread_epd(%s)", OffsetEPD))
end
function UnitCountEPD(Unit, Player) --Basic/TrgUnit,TrgPlayer/Get EPD of unit count of [Unit] for [Player].
	Player = ParsePlayer(Player)
    Unit = ParseUnit(Unit)

    Offset = 0x582324
	if IsNumber(Player) and IsNumber(Unit) then
		Offset = Offset + (Unit * 12 + Player) * 4
		return string.format("EPD(0x%X)", Offset)
	else
		return string.format("EPD(0x%X) + %s * 12 + %s", Offset, Unit, Player)
	end
end