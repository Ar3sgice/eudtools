function KeyDown(Key) --MSQC/Key/Key [Key] is pressed down.
	keyarray = "VKeyDown_" .. Key
	--AddMSQCPlugin("NotTyping ; KeyDown(" .. Key .. ") : " .. keyarray .. ", 1")
	AddMSQCPlugin(Key, keyarray, "KeyDown", "NotTyping")


	echo("MemoryEPD(EPD(msqcvar." .. keyarray .. ") + getcurpl(), Exactly, 1)")
end
function KeyUp(Key) --MSQC/Key/Key [Key] is released.
	keyarray = "VKeyUp_" .. Key
	--AddMSQCPlugin("NotTyping ; KeyDown(" .. Key .. ") : " .. keyarray .. ", 1")
	AddMSQCPlugin(Key, keyarray, "KeyUp", "NotTyping")


	echo("MemoryEPD(EPD(msqcvar." .. keyarray .. ") + getcurpl(), Exactly, 1)")
end
function KeyPress(Key) --MSQC/Key/Key [Key] is pressed.
	keyarray = "VKeyPress_" .. Key
	--AddMSQCPlugin("NotTyping ; KeyDown(" .. Key .. ") : " .. keyarray .. ", 1")
	AddMSQCPlugin(Key, keyarray, "KeyPress", "NotTyping")

	echo("MemoryEPD(EPD(msqcvar." .. keyarray .. ") + getcurpl(), Exactly, 1)")
end

function MouseDown(Button) --MSQC/Button/Mouse button [Button] is pressed down.
	keyarray = "VMouseDown_" .. Button
	--AddMSQCPlugin("NotTyping ; KeyDown(" .. Key .. ") : " .. keyarray .. ", 1")
	AddMSQCPlugin(Button, keyarray, "MouseDown", "")


	echo("MemoryEPD(EPD(msqcvar." .. keyarray .. ") + getcurpl(), Exactly, 1)")
end

function MouseUp(Button) --MSQC/Button/Mouse button [Button] is released.
	keyarray = "VMouseUp_" .. Button
	--AddMSQCPlugin("NotTyping ; KeyDown(" .. Key .. ") : " .. keyarray .. ", 1")
	AddMSQCPlugin(Button, keyarray, "MouseUp", "")


	echo("MemoryEPD(EPD(msqcvar." .. keyarray .. ") + getcurpl(), Exactly, 1)")
end

function MosePress(Button) --MSQC/Button/Mouse button [Button] is pressed.
	keyarray = "VMousePress_" .. Button
	--AddMSQCPlugin("NotTyping ; KeyDown(" .. Key .. ") : " .. keyarray .. ", 1")
	AddMSQCPlugin(Button, keyarray, "MousePress", "")


	echo("MemoryEPD(EPD(msqcvar." .. keyarray .. ") + getcurpl(), Exactly, 1)")
end
