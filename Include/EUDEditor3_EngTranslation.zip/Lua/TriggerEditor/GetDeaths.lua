function GetDeaths(Unit,Player) --Basic/TrgUnit,TrgPlayer/Get deaths count of [Unit] for [Player].
	Unit = ParseUnit(Unit)
    Player = ParsePlayer(Player)

	str = string.format("dwread_epd(EPD(0x58A364 + (%s * 12 + %s) * 4))",Unit , Player)
	echo(str)
end