GetDeaths
GetCounterTimer
GetElapsedTime
BtnRefresh
SetButton

# Set과 Get이 있는 함수
UnitsDat
WeaponsDat
FlingyDat
SpritesDat
ImagesDat
UpgradesDat
TechdataDat
OrdersDat
Resource
Supply
Score
Light
Upgrade
Tech
Kills
UnitCount
CompletedUnitCount
PlayerUnitsAvailable
Vision
PlayerAlliances