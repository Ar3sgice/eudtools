function SeletionEPD(Player, Number) --Basic/TrgPlayer,Number/Selection [Number] for [Player].
	Player = ParsePlayer(Player)
	if IsNumber(Player) then
		return string.format("EPD(0x%X) + %s", 0x6284E8 + 0x30 * Player, Number) 
	else
		return string.format("EPD(0x%X) + %s * 0xC + %s", 0x6284E8 ,Player, Number) 
	end
end