function SetSupply(SupplyType, Player, Modifier, Amount) --Supplies/SupplyType,TrgPlayer,TrgModifier,Number/Set supply count for [Player]: [Modifier] [Amount] for [SupplyType].
	ScoreType = ParseEUDScore(ScoreType)
	Player = ParsePlayer(Player)
    Modifier = ParseModifier(Modifier)
	OffsetEPD = SupplyEPD(SupplyType, Player)


	rstr = string.format("SetMemoryEPD(%s, %s, %s)",OffsetEPD, Modifier, Amount)
	echo(rstr)
end
function CurrentSupply(SupplyType, Player, Comparison, Amount) --Supplies/SupplyType,TrgPlayer,TrgComparison,Number/[Player] has [SupplyType] supply of [Comparison] [Amount].
	ScoreType = ParseEUDScore(ScoreType)
	Player = ParsePlayer(Player)
    Comparison = ParseComparison(Comparison)
	OffsetEPD = SupplyEPD(SupplyType, Player)


	rstr = string.format("MemoryEPD(%s, %s, %s)",OffsetEPD, Comparison, Amount)
	echo(rstr)
end
function GetSupply(SupplyType, Player) --Supplies/SupplyType,TrgPlayer/Get supply count of [SupplyType] for [Player].
	ScoreType = ParseEUDScore(ScoreType)
	Player = ParsePlayer(Player)
	OffsetEPD = SupplyEPD(SupplyType, Player)

	echo(string.format("dwread_epd(%s)", OffsetEPD))
end
function SupplyEPD(SupplyType, Player) --Supplies/SupplyType,TrgPlayer/Get EPD of supply count of [SupplyType] for [Player].
	ScoreType = ParseEUDScore(ScoreType)
	Player = ParsePlayer(Player)
	ScoreOffset = GetEUDScoreOffset(ScoreType)
	if IsNumber(Player) then
		ScoreOffset = ScoreOffset + Player * 4
		return string.format("EPD(0x%X)", ScoreOffset)
	else
		return string.format("EPD(%s) + %s", ScoreOffset, Player)
	end
end