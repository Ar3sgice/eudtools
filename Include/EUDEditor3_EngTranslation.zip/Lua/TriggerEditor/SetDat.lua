function SetUnitsDat(DatType, Index, Value, Modifier) --DatFile/UnitsDat,TrgUnit,Number,TrgModifier/Set [DatType] value for [Index]: [Modifier] [Value].
	Unit = ParseUnit(Index)
	Modifier = ParseModifier(Modifier)
    str = SetDatFile("units", DatType, Unit, Value, Modifier)
	echo(str)
end
function SetWeaponsDat(DatType, Index, Value, Modifier) --DatFile/WeaponsDat,Weapon,Number,TrgModifier/Set [DatType] value for [Index]: [Modifier] [Value].
	Weapon = ParseWeapon(Index)
	Modifier = ParseModifier(Modifier)
    str = SetDatFile("weapons", DatType, Weapon, Value, Modifier)
	echo(str)
end
function SetFlingyDat(DatType, Index, Value, Modifier) --DatFile/FlingyDat,Flingy,Number,TrgModifier/Set [DatType] value for [Index]: [Modifier] [Value].
	Flingy = ParseFlingy(Index)
	Modifier = ParseModifier(Modifier)
    str = SetDatFile("flingy", DatType, Flingy, Value, Modifier)
	echo(str)
end
function SetSpritesDat(DatType, Index, Value, Modifier) --DatFile/SpritesDat,Sprite,Number,TrgModifier/Set [DatType] value for [Index]: [Modifier] [Value].
	Sprite = ParseSprites(Index)
	Modifier = ParseModifier(Modifier)
    str = SetDatFile("sprites", DatType, Sprite, Value, Modifier)
	echo(str)
end
function SetImagesDat(DatType, Index, Value, Modifier) --DatFile/ImagesDat,Image,Number,TrgModifier/Set [DatType] value for [Index]: [Modifier] [Value].
	Image = ParseImages(Index)
	Modifier = ParseModifier(Modifier)
    str = SetDatFile("images", DatType, Image, Value, Modifier)
	echo(str)
end
function SetUpgradesDat(DatType, Index, Value, Modifier) --DatFile/UpgradesDat,Upgrade,Number,TrgModifier/Set [DatType] value for [Index]: [Modifier] [Value].
	Upgrade = ParseUpgrades(Index)
	Modifier = ParseModifier(Modifier)
    str = SetDatFile("upgrades", DatType, Upgrade, Value, Modifier)
	echo(str)
end
function SetTechdataDat(DatType, Index, Value, Modifier) --DatFile/TechdataDat,Tech,Number,TrgModifier/Set [DatType] value for [Index]: [Modifier] [Value].
	Tech = ParseTech(Index)
	Modifier = ParseModifier(Modifier)
    str = SetDatFile("techdata", DatType, Tech, Value, Modifier)
	echo(str)
end
function SetOrdersDat(DatType, Index, Value, Modifier) --DatFile/OrdersDat,Order,Number,TrgModifier/Set [DatType] value for [Index]: [Modifier] [Value].
	Order = ParseOrder(Index)
	Modifier = ParseModifier(Modifier)
    str = SetDatFile("orders", DatType, Order, Value, Modifier)
	echo(str)
end