function GetElapsedTime() --Basic//Get the current elapsed time.
	echo("dwread_epd(EPD(0x58D6F8))")
end
function ElapsedTimeOffset() --Basic//Get the memory offset of elapsed time.
	echo("0x58D6F8")
end
