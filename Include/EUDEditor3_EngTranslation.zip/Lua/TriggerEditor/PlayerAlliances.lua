function SetPlayerAlliances(Player, DestPlayer, AllyStatus) --Alliance/TrgPlayer,TrgPlayer,TrgAllyStatus/Set alliance from [Player] on [DestPlayer] to[AllyStatus].
	Player = ParsePlayer(Player)
	DestPlayer = ParsePlayer(DestPlayer)
	AllyStatus = ParseAllyStatus(AllyStatus)
	offsetEPD = PlayerAlliancesEPD(Player)

	if IsNumber(DestPlayer) then
		Mod = DestPlayer % 4
		RPlayer = DestPlayer - Mod
		RPlayer = RPlayer / 4

		if Mod == 0 then
    		Mask = "0xFF"
    	elseif Mod == 1 then
    		Mask = "0xFF00"
    	elseif Mod == 2 then
    		Mask = "0xFF0000"
    	elseif Mod == 3 then
    		Mask = "0xFF000000"
    	end

    	if IsNumber(AllyStatus) then
			rstr = string.format("SetMemoryXEPD(%s + %s, SetTo, %s, %s)", offsetEPD, RPlayer, AllyStatus * math.pow(256, Mod), Mask)
		else
			rstr = string.format("SetMemoryXEPD(%s + %s, SetTo, %s, %s)", offsetEPD, RPlayer, AllyStatus .. " * " .. math.pow(256, Mod), Mask)
    	end


	else
		offset = PlayerAlliances(Player)
		rstr = string.format("bwrite(%s + %s, %s)", offset, DestPlayer, AllyStatus)
	end

	echo(rstr)
end
function CurrentPlayerAlliances(Player, DestPlayer, AllyStatus) --Alliance/TrgPlayer,TrgPlayer,TrgAllyStatus/Alliance from [Player] on [DestPlayer] is currently [AllyStatus].
	Player = ParsePlayer(Player)
	DestPlayer = ParsePlayer(DestPlayer)
	AllyStatus = ParseAllyStatus(AllyStatus)
	offsetEPD = PlayerAlliancesEPD(Player)

	if IsNumber(DestPlayer) then
		Mod = DestPlayer % 4
		RPlayer = DestPlayer - Mod
		RPlayer = RPlayer / 4

		if Mod == 0 then
    		Mask = "0xFF"
    	elseif Mod == 1 then
    		Mask = "0xFF00"
    	elseif Mod == 2 then
    		Mask = "0xFF0000"
    	elseif Mod == 3 then
    		Mask = "0xFF000000"
    	end

    	if IsNumber(AllyStatus) then
			rstr = string.format("MemoryXEPD(%s + %s, Exactly, %s, %s)", offsetEPD, RPlayer, AllyStatus * math.pow(256, Mod), Mask)
		else
			rstr = string.format("MemoryXEPD(%s + %s, Exactly, %s, %s)", offsetEPD, RPlayer, AllyStatus .. " * " .. math.pow(256, Mod), Mask)
    	end

	else
		offset = PlayerAlliances(Player)
		rstr = string.format("bread(%s + %s) == %s", offset, DestPlayer, AllyStatus)
	end

	echo(rstr)
end
function GetPlayerAlliances(Player, DestPlayer) --Alliance/TrgPlayer,TrgPlayer/Get alliance status from [Player] to [DestPlayer].
	Player = ParsePlayer(Player)
	DestPlayer = ParsePlayer(DestPlayer)
	offsetEPD = PlayerAlliancesEPD(Player)

	if IsNumber(DestPlayer) then
		Mod = DestPlayer % 4
		RPlayer = DestPlayer - Mod
		RPlayer = RPlayer / 4

		rstr = string.format("bread_epd(%s + %s, %s)", offsetEPD, RPlayer, Mod)
	else
		offset = PlayerAlliances(Player)
		rstr = string.format("bread(%s + %s)", offset, DestPlayer)
	end

	echo(rstr)
end
function PlayerAlliancesEPD(Player) --Alliance/TrgPlayer/Get EPD for alliances of [Player].
	Player = ParsePlayer(Player)

	if IsNumber(Player) then
		return string.format("EPD(0x%X)", 0x58D634 + 0xC * Player) 
	else
		return string.format("EPD(0x%X) + %s * 3", 0x58D634 ,Player) 
	end
end
function PlayerAlliances(Player) --Alliance/TrgPlayer/Get memory offset for alliances of [Player].
	Player = ParsePlayer(Player)

	if IsNumber(Player) then
		return string.format("0x%X", 0x58D634 + 0xC * Player) 
	else
		return string.format("0x%X + %s * 12", 0x58D634 ,Player) 
	end
end
