function SetLight(Modifier, Amount) --Basic/TrgModifier,Number/Set the current light value: [Modifier] [Amount].
    Modifier = ParseModifier(Modifier)
    Offset = LightOffset()
	echo(string.format("SetMemoryEPD(EPD(%s), %s, %s)", Offset, Modifier, Amount))
end
function GetLight() --Basic//Get the current light value.
    Offset = LightOffset()
	echo(string.format("dwread_epd(EPD(%s))", Offset))
end
function LightOffset() --Basic//Get the light offset.
	return "0x657A9C"
end