function SetScore(Score, Player, Modifier, Amount) --Basic/EUDScore,TrgPlayer,TrgModifier,Number/Set score for [Player]: [Modifier] [Amount] for [Score].
	ScoreType = ParseEUDScore(ScoreType)
	Player = ParsePlayer(Player)
    Modifier = ParseModifier(Modifier)
	OffsetEPD = ScoreEPD(Score, Player)


	rstr = string.format("SetMemoryEPD(%s, %s, %s)",OffsetEPD, Modifier, Amount)
	echo(rstr)
end
function CurrentScore(Score, Player, Comparison, Amount) --Basic/EUDScore,TrgPlayer,TrgComparison,Number/[Player] has [Comparison] [Amount] of [Score].
	ScoreType = ParseEUDScore(ScoreType)
	Player = ParsePlayer(Player)
    Comparison = ParseComparison(Comparison)
	OffsetEPD = ScoreEPD(Score, Player)


	rstr = string.format("MemoryEPD(%s, %s, %s)",OffsetEPD, Comparison, Amount)
	echo(rstr)
end
function GetScore(Score, Player) --Basic/EUDScore,TrgPlayer/Get [Score] score for [Player].
	ScoreType = ParseEUDScore(ScoreType)
	Player = ParsePlayer(Player)
	OffsetEPD = ScoreEPD(Score, Player)

	echo(string.format("dwread_epd(%s)", OffsetEPD))
end
function ScoreEPD(Score, Player) --Basic/EUDScore,TrgPlayer/Get EPD of [Score] score for [Player].
	ScoreType = ParseEUDScore(ScoreType)
	Player = ParsePlayer(Player)
	ScoreOffset = GetEUDScoreOffset(ScoreType)
	if IsNumber(Player) then
		ScoreOffset = ScoreOffset + Player * 4
		return string.format("EPD(0x%X)", ScoreOffset)
	else
		return string.format("EPD(%s) + %s", ScoreOffset, Player)
	end
end