function UnitsDatOffset(DatType) --DatFile/UnitsDat/Return the offset of [DatType].
    str = DatOffset("units", DatType)
	return str
end
function WeaponsDatOffset(DatType) --DatFile/WeaponsDat/Return the offset of [DatType].
    str = DatOffset("weapons", DatType)
	return str
end
function FlingyDatOffset(DatType) --DatFile/FlingyDat/Return the offset of [DatType].
    str = DatOffset("flingy", DatType)
	return str
end
function SpritesDatOffset(DatType) --DatFile/SpritesDat/Return the offset of [DatType].
    str = DatOffset("sprites", DatType)
	return str
end
function ImagesDatOffset(DatType) --DatFile/ImagesDat/Return the offset of [DatType].
    str = DatOffset("images", DatType)
	return str
end
function UpgradesDatOffset(DatType) --DatFile/UpgradesDat/Return the offset of [DatType].
    str = DatOffset("upgrades", DatType)
	return str
end
function TechdataDatOffset(DatType) --DatFile/TechdataDat/Return the offset of [DatType].
    str = DatOffset("techdata", DatType)
	return str
end
function OrdersDatOffset(DatType) --DatFile/OrdersDat/Return the offset of [DatType].
    str = DatOffset("orders", DatType)
	return str
end