function UnitsDat(DatType, Index, Value, Comparison) --DatFile/UnitsDat,TrgUnit,Number,TrgComparison/[DatType] value for [Index] is [Comparison] [Value].
	Unit = ParseUnit(Index)
	Comparison = ParseComparison(Comparison)
    str = ConditionDatFile("units", DatType, Unit, Value, Comparison)
	echo(str)
end
function WeaponsDat(DatType, Index, Value, Comparison) --DatFile/WeaponsDat,Weapon,Number,TrgComparison/[DatType] value for [Index] is [Comparison] [Value].
	Weapon = ParseWeapon(Index)
	Comparison = ParseComparison(Comparison)
    str = ConditionDatFile("weapons", DatType, Weapon, Value, Comparison)
	echo(str)
end
function FlingyDat(DatType, Index, Value, Comparison) --DatFile/FlingyDat,Flingy,Number,TrgComparison/[DatType] value for [Index] is [Comparison] [Value].
	Flingy = ParseFlingy(Index)
	Comparison = ParseComparison(Comparison)
    str = ConditionDatFile("flingy", DatType, Flingy, Value, Comparison)
	echo(str)
end
function SpritesDat(DatType, Index, Value, Comparison) --DatFile/SpritesDat,Sprite,Number,TrgComparison/[DatType] value for [Index] is [Comparison] [Value].
	Sprite = ParseSprites(Index)
	Comparison = ParseComparison(Comparison)
    str = ConditionDatFile("sprites", DatType, Sprite, Value, Comparison)
	echo(str)
end
function ImagesDat(DatType, Index, Value, Comparison) --DatFile/ImagesDat,Image,Number,TrgComparison/[DatType] value for [Index] is [Comparison] [Value].
	Image = ParseImage(Index)
	Comparison = ParseComparison(Comparison)
    str = ConditionDatFile("images", DatType, Image, Value, Comparison)
	echo(str)
end
function UpgradesDat(DatType, Index, Value, Comparison) --DatFile/UpgradesDat,Upgrade,Number,TrgComparison/[DatType] value for [Index] is [Comparison] [Value].
	Upgrade = ParseUpgrade(Index)
	Comparison = ParseComparison(Comparison)
    str = ConditionDatFile("upgrades", DatType, Upgrade, Value, Comparison)
	echo(str)
end
function TechdataDat(DatType, Index, Value, Comparison) --DatFile/TechdataDat,Tech,Number,TrgComparison/[DatType] value for [Index] is [Comparison] [Value].
	Tech = ParseTech(Index)
	Comparison = ParseComparison(Comparison)
    str = ConditionDatFile("techdata", DatType, Tech, Value, Comparison)
	echo(str)
end
function OrdersDat(DatType, Index, Value, Comparison) --DatFile/OrdersDat,Order,Number,TrgComparison/[DatType] value for [Index] is [Comparison] [Value].
	Order = ParseOrder(Index)
	Comparison = ParseComparison(Comparison)
    str = ConditionDatFile("orders", DatType, Order, Value, Comparison)
	echo(str)
end