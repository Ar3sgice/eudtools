function GetUnitsDat(DatType, Index) --DatFile/UnitsDat,TrgUnit/Dat value of [DatType] for [Index].
	Unit = ParseUnit(Index)
    str = GetDatFile("units", DatType, Unit)
	echo(str)
end
function GetWeaponsDat(DatType, Index) --DatFile/WeaponsDat,Weapon/Dat value of [DatType] for [Index].
	Weapon = ParseWeapon(Index)
    str = GetDatFile("weapons", DatType, Weapon)
	echo(str)
end
function GetFlingyDat(DatType, Index) --DatFile/FlingyDat,Flingy/Dat value of [DatType] for [Index].
	Flingy = ParseFlingy(Index)
    str = GetDatFile("flingy", DatType, Flingy)
	echo(str)
end
function GetSpritesDat(DatType, Index) --DatFile/SpritesDat,Sprite/Dat value of [DatType] for [Index].
	Sprite = ParseSprites(Index)
    str = GetDatFile("sprites", DatType, Sprite)
	echo(str)
end
function GetImagesDat(DatType, Index) --DatFile/ImagesDat,Image/Dat value of [DatType] for [Index].
	Image = ParseImage(Index)
    str = GetDatFile("images", DatType, Image)
	echo(str)
end
function GetUpgradesDat(DatType, Index) --DatFile/UpgradesDat,Upgrade/Dat value of [DatType] for [Index].
	Upgrade = ParseUpgrade(Index)
    str = GetDatFile("upgrades", DatType, Upgrade)
	echo(str)
end
function GetTechdataDat(DatType, Index) --DatFile/TechdataDat,Tech/Dat value of [DatType] for [Index].
	Tech = ParseTech(Index)
    str = GetDatFile("techdata", DatType, Tech)
	echo(str)
end
function GetOrdersDat(DatType, Index) --DatFile/OrdersDat,Order/Dat value of [DatType] for [Index].
	Order = ParseOrder(Index)
    str = GetDatFile("orders", DatType, Order)
	echo(str)
end